package com.andreisingeleytsev.challengeswheelapp.ui.utils

sealed class UIEvents(){
    object Roll: UIEvents()
}
