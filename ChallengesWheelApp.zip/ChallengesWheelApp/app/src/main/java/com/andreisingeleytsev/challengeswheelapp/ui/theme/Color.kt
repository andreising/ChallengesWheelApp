package com.andreisingeleytsev.challengeswheelapp.ui.theme

import androidx.compose.ui.graphics.Color

val OnboardCard1Color = Color(0x8C930DA9)
val OnboardCard2Color = Color(0x4DA90D61)
val OnboardCard3Color = Color(0x8CF47D0F)
val OnboardCard4Color = Color(0x8CFFD80D)
val OnboardCard5Color = Color(0x8C7DDC04)
val Pink = Color(0xFFCC40DF)
val Pink2 = Color(0xFFFF3A81)
val Orange = Color(0xFFFF961C)
val Yellow = Color(0xFFFFD600)
val Green = Color(0xFF7FDA0B)
val MainPurple = Color(0xFFBE35FF)
val MainOrange = Color(0xFFF4A345)
val Golden = Color(0xFFFFE8AE)