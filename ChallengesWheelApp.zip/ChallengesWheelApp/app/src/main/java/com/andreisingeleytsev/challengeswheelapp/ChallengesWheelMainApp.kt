package com.andreisingeleytsev.challengeswheelapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ChallengesWheelMainApp:Application() {
}