package com.andreisingeleytsev.challengeswheelapp.ui.utils

object Routes {
    const val MENU_SCREEN = "menu_screen"
    const val MAIN_SCREEN = "main_screen"
    const val GAME_SCREEN = "game_screen"
}